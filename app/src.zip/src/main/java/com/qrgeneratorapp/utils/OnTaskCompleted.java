package com.qrgeneratorapp.utils;

import android.graphics.Bitmap;

/**
 * Created by inmkhan021 on 7/11/2017.
 */

public interface OnTaskCompleted {
    void onTaskCompleted(Bitmap bitmap);
}
