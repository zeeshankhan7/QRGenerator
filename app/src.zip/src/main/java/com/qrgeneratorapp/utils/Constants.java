package com.qrgeneratorapp.utils;

/**
 * Created by inmkhan021 on 7/12/2017.
 */

public class Constants {

    public static final String REQUEST_MESSAGE= " You can't leave the field empty ";
}
